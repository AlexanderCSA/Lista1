﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double prod1;
            double prod2;
            double prod3;
            double prod4;
            double prod5;
            double pag;
            double troco;

            Console.WriteLine("Exercício 12\nCálculo do pagamento e troco de 5 produtos \n\n");

            Console.Write("Digite o Valor do Primeiro Produto: R$ ");
            prod1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o Valor do Segundo Produto: R$ ");
            prod2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o Valor do Terceiro Produto: R$ ");
            prod3 = double.Parse(Console.ReadLine());

            Console.Write("Digite o Valor do Quarto Produto: R$ ");
            prod4 = double.Parse(Console.ReadLine());

            Console.Write("Digite o Valor do Quinto Produto: R$ ");
            prod5 = double.Parse(Console.ReadLine());

            Console.Write("\n\n ");

            Console.Write("Digite o Valor do Pagamento: R$ ");
            pag = double.Parse(Console.ReadLine());

            Console.Write("\n\n ");

            troco = pag - (prod1 + prod2 + prod3 + prod4 + prod5);
            Console.WriteLine("Troco: " + troco.ToString("C"));

            Console.Write("\n\n ");
        }
    }
}
