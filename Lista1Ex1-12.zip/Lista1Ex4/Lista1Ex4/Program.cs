﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1;
            double altura;

            Console.WriteLine("Exercício 4\nCalcular a área de um triângulo \n\n");

            Console.WriteLine("Insira o valor da base do triângulo: ");

            base1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Insira o valor da altura do triângulo: ");

            altura = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("A área do triângulo é: \n" + ((base1*altura)/2));
            
        }
    }
}
