﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta;
            double resultado;

            Console.WriteLine("Exercício 2\nCalcular a área de um quadrado à partir de sua aresta \n\n");

            Console.WriteLine("Digite o valor da aresta: ");
            aresta = double.Parse(Console.ReadLine());

            resultado = aresta * aresta;

            Console.WriteLine("A área do quadrado à partir de sua aresta é: \n" +resultado);
        }
    }
}
