﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double valor3; 
            double valor4;
            double media;

            Console.WriteLine("Exercício 5\nMédia de quatro valores \n\n");

            Console.Write("Insira o primeiro valor: ");
            valor1 = double.Parse(Console.ReadLine());

            Console.Write("Insira o segundo valor: ");
            valor2 = double.Parse(Console.ReadLine());

            Console.Write("Insira o terceiro valor: ");
            valor3 = double.Parse(Console.ReadLine());

            Console.Write("Insira o quarto valor: ");
            valor4 = double.Parse(Console.ReadLine());

            media = (valor1 + valor2 + valor3 + valor4) / 4;

            Console.WriteLine("A média dos 4 valores é: " + media);
        }
    }
}
