﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double area;
            Console.WriteLine("Exercício 9\nÁrea de um círculo a partir de seu diâmetro \n\n");

            Console.Write("Insira o Diâmetro do Circulo em centímetros: ");
            valor = double.Parse(Console.ReadLine());

            area = Math.PI * Math.Pow((valor / 2), 2);
            Console.WriteLine("A área do círculo é: " + area + "cm²");
        }
    }
}
