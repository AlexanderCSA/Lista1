﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x;
            double y;
            double resultado;

            Console.WriteLine("Exercício 11\nCalcular o valor de X elevado a Y \n\n");

            Console.Write("Digite o Valor de X: ");
            x = double.Parse(Console.ReadLine());

            Console.Write("Digite o Valor de Y: ");
            y = double.Parse(Console.ReadLine());

            resultado = Math.Pow(x, y);
            Console.WriteLine("O valor de X Elevado a Y é: " + resultado);
        }
    }
}
