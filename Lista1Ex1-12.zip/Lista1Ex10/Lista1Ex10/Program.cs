﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double dolar;
            double cotacao;
            double real;

            Console.WriteLine("Exercício 10\nDólar em Real \n\n");

            Console.Write("Insira a Cotação Atual do Dólar: R$");
            cotacao = double.Parse(Console.ReadLine());

            Console.Write("Insira a quantia em Dólar: US$ ");
            dolar = double.Parse(Console.ReadLine());
            real = dolar * cotacao;
            Console.WriteLine("Valor em Reais: " + real.ToString("C"));
        }
    }
}
