﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diagonal;
            double lado;
            double area;

            Console.WriteLine("Exercício 3\nCalcular a área do quadrado a partir da sua diagonal \n\n");

            Console.Write("Digite o valor da Diagonal em centímetros: ");
            diagonal = double.Parse(Console.ReadLine());

            lado = diagonal / Math.Sqrt(2);
            area = Math.Pow(lado, 2);
            Console.WriteLine("Área do quadrado à partir de sua diagonal é: " + area + "Cm²");
        }
    }
}
