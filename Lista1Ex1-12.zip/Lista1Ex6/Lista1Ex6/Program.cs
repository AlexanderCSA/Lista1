﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double media;

            Console.WriteLine("Exercício 6\nMédia geométrica a partir de dois valores \n\n");

            
            Console.Write("Insira o primeiro valor: ");
            valor1 = double.Parse(Console.ReadLine());

            Console.Write("Insira o segundo valor: ");
            valor2 = double.Parse(Console.ReadLine());

            media = valor1 * valor2;
            media = Math.Sqrt(media);

            Console.WriteLine("A média geométrica dos valores inseridos é: " + media);
        }
    }
}
