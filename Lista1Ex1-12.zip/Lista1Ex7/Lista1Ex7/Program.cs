﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double milha;
            double resultado;

            Console.WriteLine("Exercício 1\nConverter milhas marítimas em quilômetros. \n\n");

            Console.Write("Digite a Milha Marítima para conversão: ");
            milha = double.Parse(Console.ReadLine());
            resultado = milha * 1.852;
            Console.WriteLine("O resultado é : " +resultado+ " Quilômetros");
        }
    }
}
