﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double area = 0;
            double base1 = 0;
            double altura = 0;

            Console.WriteLine("Exercício 1\nCalcular a área de um retângulo \n\n");

            Console.WriteLine("Insira o valor da base: ");
            base1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Insira o valor da altura: ");
            altura = double.Parse(Console.ReadLine());

            area = base1 * altura;
            Console.Write("A área do retângulo é: " + area + " centímetros quadrados \n\n") ;
            
        }
    }
}
