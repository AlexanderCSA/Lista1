﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.WriteLine("Exercício 6\nMédia geométrica a partir de dois valores \n\n");
            
            Console.Write("Insira um valor em graus Celsius: ");
            valor = double.Parse(Console.ReadLine());
            resultado = (valor * 1.8) + 32;
            Console.WriteLine("O valor em Fahrenheit é: " + resultado + "\n");
        }
    }
}
